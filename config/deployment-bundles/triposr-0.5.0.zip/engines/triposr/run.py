"""Offline TripoSR factory entry. v0.0.1 / Unclecow."""
import argparse
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['HF_HOME'] = str(ROOT / 'cache' / 'huggingface')
sys.path[:0] = [str(ROOT / 'src'), str(ROOT.parents[1] / 'scripts')]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input')
    parser.add_argument('--output')
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    import numpy as np
    import torch
    from PIL import Image
    from tsr.system import TSR
    from tsr.models.isosurface import MARCHING_CUBES_BACKEND
    from tsr.utils import resize_foreground
    from factory_image import prepare_image
    if args.check:
        print(json.dumps({'imports': True, 'torch': torch.__version__, 'cuda': torch.cuda.is_available(), 'surfaceBackend': MARCHING_CUBES_BACKEND}))
        return
    if not args.input or not args.output:
        parser.error('--input and --output are required')
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA GPU is required')
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    image = resize_foreground(prepare_image(args.input, output), 0.85)
    rgba = np.asarray(image).astype(np.float32) / 255.0
    rgb = rgba[:, :, :3] * rgba[:, :, 3:4] + (1 - rgba[:, :, 3:4]) * 0.5
    image = Image.fromarray((rgb * 255).astype(np.uint8))
    started = time.monotonic()
    model = TSR.from_pretrained(str(ROOT / 'models'), config_name='config.yaml', weight_name='model.ckpt')
    model.renderer.set_chunk_size(4096)
    model.to('cuda')
    with torch.inference_mode():
        codes = model([image], device='cuda')
        mesh = model.extract_mesh(codes, has_vertex_color=True, resolution=256)[0]
    if len(mesh.vertices) == 0 or len(mesh.faces) == 0:
        raise RuntimeError('Model produced an empty mesh')
    mesh.export(output / 'model.glb')
    result = {'engine': 'triposr', 'seconds': round(time.monotonic()-started, 2),
              'vertices': len(mesh.vertices), 'triangles': len(mesh.faces), 'appearance': 'vertex colors',
              'surfaceBackend': MARCHING_CUBES_BACKEND,
              'rigged': False, 'visualAcceptance': 'unreviewed'}
    (output / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result), flush=True)

if __name__ == '__main__':
    main()
