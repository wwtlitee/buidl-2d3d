param([Parameter(Mandatory)][string]$InputImage,[Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot '.venv\Scripts\python.exe') -u (Join-Path $PSScriptRoot 'run.py') --input $InputImage --output $OutputDirectory
if($LASTEXITCODE -ne 0){throw "TripoSR failed: $LASTEXITCODE"}
